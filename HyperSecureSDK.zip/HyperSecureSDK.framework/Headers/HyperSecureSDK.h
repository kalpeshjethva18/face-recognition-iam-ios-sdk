//
//  HyperSecureSDK.h
//  HyperSecureSDK
//
//  Created by Srinija on 31/10/17.
//  Copyright © 2017 hyperverge. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for HyperSecureSDK.
FOUNDATION_EXPORT double HyperSecureSDKVersionNumber;

//! Project version string for HyperSecureSDK.
FOUNDATION_EXPORT const unsigned char HyperSecureSDKVersionString[];



